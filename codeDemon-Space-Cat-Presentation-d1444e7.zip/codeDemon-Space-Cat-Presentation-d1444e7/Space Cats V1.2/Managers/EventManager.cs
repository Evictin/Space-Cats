﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using System.Text;

namespace Space_Cats_V1._2
{
    class EventManager
    {
        /*//Some stuff for events
         * 
         * private GameObject z_achivementFail;
        private bool z_achivementFailUnlocked = false;
         * 
         * 
         * 
         * 
         * //Load Achivement Stuff
            this.z_achivementFail = new GameObject(Content.Load<Texture2D>("Images\\AchievementFailed"));
            this.z_achivementFail.setPosition(new Vector2((this.z_viewportRec.Width/2)-(this.z_achivementFail.getSprite().Width/2),
                                                            this.z_viewportRec.Height-100));
         * 
         * 
         * 
         *  //Check Achivements
            if (this.z_gameTimer > this.z_interval1 && !this.z_achivementFailUnlocked)
            {
                this.z_achivementFail.setIsAlive(true);
                
                this.z_achivementFailUnlocked = true;
            }
            if (this.z_gameTimer > 21)
                this.z_achivementFail.setIsAlive(false);

         * 
         * 
         * 
         * //Draw any achivements
            if (this.z_achivementFail.getIsAlive())
                this.z_spriteBatch.Draw(this.z_achivementFail.getSprite(), this.z_achivementFail.getPosition(), Color.White);
         * 
         * 
         * 
         * */



    }
}
