﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using System.Text;

namespace Space_Cats_V1._2
{
    class CollisionManager
    {
        /*
         * Collision to watch out for:
         * 1.) PlayerShip collides with Asteroid
         * 2.) PlayerShip collides with EnemyShip
         * 3.) PlayerShip collides with EnemyMissle
         * 4.) PlayerMissle collides with Asteroid
         * 5.) PlayerMissle collides with EnemyShip
         * 
         * */

        //Instance Variables -----------------------------------------------------------------------------


        //Constructor ------------------------------------------------------------------------------------


        //Accessor Methods -------------------------------------------------------------------------------

        //Mutator Methods --------------------------------------------------------------------------------

        //Other Methods ----------------------------------------------------------------------------------

    }
}
