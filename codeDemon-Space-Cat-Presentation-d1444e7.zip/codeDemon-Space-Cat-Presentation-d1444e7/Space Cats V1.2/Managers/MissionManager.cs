﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Space_Cats_V1._2
{
    class MissionManager
    {
        //This class will handle the missions?




    }
}
